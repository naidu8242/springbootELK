package com.concretepage.articleelasticrepository;

public class ArticleElasticRepository {

}
